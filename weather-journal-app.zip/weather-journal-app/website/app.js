/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();


let baseurl= "https://api.openweathermap.org/data/2.5/weather?zip=";
const key= "&appid=63fbded61a1d0c851628feb302098037&units=metric";


const getData = async (baseurl,region,key) =>
{
    //a variable to hold what is returned from the fetch request
    const request = await fetch(baseurl+region+key);
    try
    {
       const data = await request.json();
       console.log(data);
       return data;
    }
    catch(error)
    {console.log(error);}
};
//adding a click event listener on the generate button 
document.getElementById('generate').addEventListener('click',performAction);
function performAction()
{
    const region= document.getElementById('zip').value;
    const feeling= document.getElementById('feelings').value;
    if(region=="")
    {alert('Enter zip code!');}
    else
        //chaining the functions
        //posting the data recieved from the API to the local server
    getData(baseurl,region,key)
        .then(function(data)
          {
            console.log(data);
            postData("/add",{date:newDate,temp:data.main.temp,feeling: feeling});
          })
        .then(function()
          {updateInterface();}); 
}

const postData = async (url= "", data ={}) =>
{
    //code to fetch route url and write request method, credentials, headers, and body
    console.log(data);
    const response = await fetch(url,{
        //to access the post route created in the server file
        method: 'POST',
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        //converts data to string to be posted on the server
        body: JSON.stringify(data), 
        });
    try
    {
        console.log(response);
        return;
    }
    catch(error)
    { console.log(error);}
}; 
const temp= document.getElementById("temp");
const date= document.getElementById("date");
const content= document.getElementById("content");

const updateInterface = async () =>
{
    const request = await fetch('/getRoute');
    try
    {
        const recievedData = await request.json();
        temp.innerHTML = recievedData.temp;
        date.innerHTML = recievedData.date;
        content.innerHTML= recievedData.feeling;
    }
    catch(error)
    {console.log(error);}
}

//calling the postData function
