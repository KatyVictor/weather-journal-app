// Setup empty JS object to act as endpoint for all routes
//To hold all app data
projectData = {};

// Require Express to run server and routes
const express= require('express');
// Start up an instance of app
const app = express();
/* Middleware*/
const bodyParser= require('body-parser');
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());
// Initialize the main project folder
app.use(express.static('website'));
// Setup Server
const port= 8080;
// the server will start listening at the port determined and will call the running function
const server= app.listen(port, running);

function running ()
{
    console.log('server is running');
    console.log("running on localhost:", port);
}

//Setting a GET Route
//whenever the url is loaded, a get request is made and the object projectData is returned as a reponse
app.get('/getRoute',function(req,res)
        {
            res.send(projectData);
        });
//hna nafs el url elly f function postData hnak
app.post('/add', function(req,res)
        {
            projectData.temp = req.body.temp;
            projectData.date = req.body.date;
            projectData.feeling = req.body.feeling;
        });